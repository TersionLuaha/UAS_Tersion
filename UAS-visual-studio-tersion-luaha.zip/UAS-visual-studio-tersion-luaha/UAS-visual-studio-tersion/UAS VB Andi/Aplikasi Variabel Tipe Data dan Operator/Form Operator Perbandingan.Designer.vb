﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form_Operator_Perbandingan
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.BLebihBesarSamaDengan = New System.Windows.Forms.Button()
        Me.lb_hasil = New System.Windows.Forms.Label()
        Me.TbHasil = New System.Windows.Forms.TextBox()
        Me.BLebihKecilSamaDengan = New System.Windows.Forms.Button()
        Me.BLebihBesar = New System.Windows.Forms.Button()
        Me.BLebihKecil = New System.Windows.Forms.Button()
        Me.BTidakSamaDengan = New System.Windows.Forms.Button()
        Me.TbNilai2 = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.TbNilai1 = New System.Windows.Forms.TextBox()
        Me.BSamaDengan = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'BLebihBesarSamaDengan
        '
        Me.BLebihBesarSamaDengan.Font = New System.Drawing.Font("Mongolian Baiti", 32.0!, System.Drawing.FontStyle.Bold)
        Me.BLebihBesarSamaDengan.Location = New System.Drawing.Point(1074, 231)
        Me.BLebihBesarSamaDengan.Name = "BLebihBesarSamaDengan"
        Me.BLebihBesarSamaDengan.Size = New System.Drawing.Size(149, 90)
        Me.BLebihBesarSamaDengan.TabIndex = 24
        Me.BLebihBesarSamaDengan.Text = ">="
        Me.BLebihBesarSamaDengan.UseVisualStyleBackColor = True
        '
        'lb_hasil
        '
        Me.lb_hasil.Font = New System.Drawing.Font("Mongolian Baiti", 36.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lb_hasil.Location = New System.Drawing.Point(340, 337)
        Me.lb_hasil.Name = "lb_hasil"
        Me.lb_hasil.Size = New System.Drawing.Size(804, 64)
        Me.lb_hasil.TabIndex = 23
        Me.lb_hasil.Text = "Hasil"
        Me.lb_hasil.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TbHasil
        '
        Me.TbHasil.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TbHasil.Font = New System.Drawing.Font("Mongolian Baiti", 36.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TbHasil.Location = New System.Drawing.Point(340, 419)
        Me.TbHasil.Name = "TbHasil"
        Me.TbHasil.ReadOnly = True
        Me.TbHasil.Size = New System.Drawing.Size(804, 77)
        Me.TbHasil.TabIndex = 22
        Me.TbHasil.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'BLebihKecilSamaDengan
        '
        Me.BLebihKecilSamaDengan.Font = New System.Drawing.Font("Mongolian Baiti", 32.0!, System.Drawing.FontStyle.Bold)
        Me.BLebihKecilSamaDengan.Location = New System.Drawing.Point(876, 231)
        Me.BLebihKecilSamaDengan.Name = "BLebihKecilSamaDengan"
        Me.BLebihKecilSamaDengan.Size = New System.Drawing.Size(180, 90)
        Me.BLebihKecilSamaDengan.TabIndex = 21
        Me.BLebihKecilSamaDengan.Text = "<="
        Me.BLebihKecilSamaDengan.UseVisualStyleBackColor = True
        '
        'BLebihBesar
        '
        Me.BLebihBesar.Font = New System.Drawing.Font("Mongolian Baiti", 32.0!, System.Drawing.FontStyle.Bold)
        Me.BLebihBesar.Location = New System.Drawing.Point(720, 231)
        Me.BLebihBesar.Name = "BLebihBesar"
        Me.BLebihBesar.Size = New System.Drawing.Size(150, 90)
        Me.BLebihBesar.TabIndex = 20
        Me.BLebihBesar.Text = ">"
        Me.BLebihBesar.UseVisualStyleBackColor = True
        '
        'BLebihKecil
        '
        Me.BLebihKecil.Font = New System.Drawing.Font("Mongolian Baiti", 32.0!, System.Drawing.FontStyle.Bold)
        Me.BLebihKecil.Location = New System.Drawing.Point(564, 231)
        Me.BLebihKecil.Name = "BLebihKecil"
        Me.BLebihKecil.Size = New System.Drawing.Size(150, 90)
        Me.BLebihKecil.TabIndex = 19
        Me.BLebihKecil.Text = "<"
        Me.BLebihKecil.UseVisualStyleBackColor = True
        '
        'BTidakSamaDengan
        '
        Me.BTidakSamaDengan.Font = New System.Drawing.Font("Mongolian Baiti", 32.0!, System.Drawing.FontStyle.Bold)
        Me.BTidakSamaDengan.Location = New System.Drawing.Point(408, 231)
        Me.BTidakSamaDengan.Name = "BTidakSamaDengan"
        Me.BTidakSamaDengan.Size = New System.Drawing.Size(150, 90)
        Me.BTidakSamaDengan.TabIndex = 18
        Me.BTidakSamaDengan.Text = "< >"
        Me.BTidakSamaDengan.UseVisualStyleBackColor = True
        '
        'TbNilai2
        '
        Me.TbNilai2.Font = New System.Drawing.Font("Mongolian Baiti", 36.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TbNilai2.Location = New System.Drawing.Point(340, 138)
        Me.TbNilai2.Name = "TbNilai2"
        Me.TbNilai2.Size = New System.Drawing.Size(804, 77)
        Me.TbNilai2.TabIndex = 17
        Me.TbNilai2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Mongolian Baiti", 36.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(12, 141)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(289, 64)
        Me.Label2.TabIndex = 16
        Me.Label2.Text = "Nilai Ke-2"
        '
        'TbNilai1
        '
        Me.TbNilai1.Font = New System.Drawing.Font("Mongolian Baiti", 36.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TbNilai1.Location = New System.Drawing.Point(340, 31)
        Me.TbNilai1.Name = "TbNilai1"
        Me.TbNilai1.Size = New System.Drawing.Size(804, 77)
        Me.TbNilai1.TabIndex = 15
        Me.TbNilai1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'BSamaDengan
        '
        Me.BSamaDengan.Font = New System.Drawing.Font("Mongolian Baiti", 32.0!, System.Drawing.FontStyle.Bold)
        Me.BSamaDengan.Location = New System.Drawing.Point(252, 231)
        Me.BSamaDengan.Name = "BSamaDengan"
        Me.BSamaDengan.Size = New System.Drawing.Size(150, 90)
        Me.BSamaDengan.TabIndex = 14
        Me.BSamaDengan.Text = "="
        Me.BSamaDengan.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Mongolian Baiti", 36.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(12, 34)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(289, 64)
        Me.Label1.TabIndex = 13
        Me.Label1.Text = "Nilai Ke-1"
        '
        'Form_Operator_Perbandingan
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1270, 583)
        Me.Controls.Add(Me.BLebihBesarSamaDengan)
        Me.Controls.Add(Me.lb_hasil)
        Me.Controls.Add(Me.TbHasil)
        Me.Controls.Add(Me.BLebihKecilSamaDengan)
        Me.Controls.Add(Me.BLebihBesar)
        Me.Controls.Add(Me.BLebihKecil)
        Me.Controls.Add(Me.BTidakSamaDengan)
        Me.Controls.Add(Me.TbNilai2)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.TbNilai1)
        Me.Controls.Add(Me.BSamaDengan)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form_Operator_Perbandingan"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Form Operator Perbandingan"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents BLebihBesarSamaDengan As System.Windows.Forms.Button
    Friend WithEvents lb_hasil As System.Windows.Forms.Label
    Friend WithEvents TbHasil As System.Windows.Forms.TextBox
    Friend WithEvents BLebihKecilSamaDengan As System.Windows.Forms.Button
    Friend WithEvents BLebihBesar As System.Windows.Forms.Button
    Friend WithEvents BLebihKecil As System.Windows.Forms.Button
    Friend WithEvents BTidakSamaDengan As System.Windows.Forms.Button
    Friend WithEvents TbNilai2 As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents TbNilai1 As System.Windows.Forms.TextBox
    Friend WithEvents BSamaDengan As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
End Class
